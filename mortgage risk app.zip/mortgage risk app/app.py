import numpy as np
import pandas as pd
import streamlit as st
import altair as alt
from pathlib import Path
from typing import Dict, Tuple


# Paths & artifact loader

APP_DIR = Path(__file__).resolve().parent
ARTIFACTS_PATH = APP_DIR / "artifacts" / "stress_app_artifacts.npz"


def load_artifacts(path: Path = ARTIFACTS_PATH):
    """Load PD vectors and macro parameters exported from notebook."""
    data = np.load(path)
    return {
        "p_baseline_rel": data["p_baseline_rel"],
        "p_baseline_real": data["p_baseline_real"],
        "su": float(data["su"]),
        "sh": float(data["sh"]),
        "sr": float(data["sr"]),
        "wu": float(data["wu"]),
        "wh": float(data["wh"]),
        "wr": float(data["wr"]),
    }



# Core stress-test logic

def odds_scaled_pd_adjust_from_probs(
    p: np.ndarray,
    delta: Dict[str, float],
    su: float,
    sh: float,
    sr: float,
    wu: float,
    wh: float,
    wr: float,
) -> np.ndarray:
    """
    Adjust PDs given macro deltas, scaling by historical std devs, on log-odds scale.
    Mirrors your notebook logic.
    """
    zu = delta.get("UNRATE", 0.0) / (su if su else 1.0)
    zh = delta.get("HPI_CHANGE", 0.0) / (sh if sh else 1.0)
    zr = delta.get("MORTGAGE30US", 0.0) / (sr if sr else 1.0)

    # Negative sign on HPI: declines raise PDs
    shift = (wu * zu) + (-wh * zh) + (wr * zr)

    eps = 1e-9
    p_clipped = np.clip(p, eps, 1 - eps)
    logit = np.log(p_clipped / (1 - p_clipped))
    p_new = 1 / (1 + np.exp(-(logit + shift)))
    return np.clip(p_new, 0.001, 0.99)


def apply_scenario(
    p0: np.ndarray,
    delta: Dict[str, float],
    su: float,
    sh: float,
    sr: float,
    wu: float,
    wh: float,
    wr: float,
) -> Tuple[np.ndarray, float]:
    """Return scenario PD vector and average PD."""
    p_s = odds_scaled_pd_adjust_from_probs(p0, delta, su, sh, sr, wu, wh, wr)
    return p_s, float(p_s.mean())


def scenario_step_df(
    p0: np.ndarray,
    delta: Dict[str, float],
    su: float,
    sh: float,
    sr: float,
    wu: float,
    wh: float,
    wr: float,
) -> pd.DataFrame:
    """
    Step-by-step mean PD as we add UNRATE → HPI_CHANGE → MORTGAGE30US shocks.
    """
    base_mean = float(p0.mean())
    steps = [("Baseline", base_mean)]

    current_delta: Dict[str, float] = {}

    sequence = [
        ("+Unemployment shock", "UNRATE"),
        ("+House price shock", "HPI_CHANGE"),
        ("+Mortgage rate shock", "MORTGAGE30US"),
    ]

    for label, drv in sequence:
        if drv in delta:
            current_delta[drv] = delta[drv]
        p_step, mean_step = apply_scenario(p0, current_delta, su, sh, sr, wu, wh, wr)
        steps.append((label, mean_step))

    df = pd.DataFrame(steps, columns=["Stage", "Mean_PD"])
    df["Mean_PD_pct"] = 100 * df["Mean_PD"]
    df["Δ_from_baseline_pp"] = (df["Mean_PD"] - base_mean) * 100
    return df


def sweep_driver_curve(
    p0: np.ndarray,
    driver: str,
    grid: np.ndarray,
    su: float,
    sh: float,
    sr: float,
    wu: float,
    wh: float,
    wr: float,
) -> pd.DataFrame:
    """
    Macro sensitivity curve: mean PD vs a grid of shocks for a single driver,
    holding the others at zero.
    """
    rows = []
    for d in grid:
        delta = {"UNRATE": 0.0, "HPI_CHANGE": 0.0, "MORTGAGE30US": 0.0}
        delta[driver] = d
        p_adj = odds_scaled_pd_adjust_from_probs(p0, delta, su, sh, sr, wu, wh, wr)
        rows.append((d, p_adj.mean()))
    return pd.DataFrame(rows, columns=["shock", "mean_PD"])


# Preset scenarios
PRESET_SCENARIOS = {
    "Baseline (no shock)": {"UNRATE": 0.0, "HPI_CHANGE": 0.0, "MORTGAGE30US": 0.0},
    "Low stress": {"UNRATE": 2.0, "HPI_CHANGE": -10.0, "MORTGAGE30US": 1.0},
    "Adverse": {"UNRATE": 5.0, "HPI_CHANGE": -20.0, "MORTGAGE30US": 2.0},
    "Custom": None,
}


# Streamlit app

def main():
    st.set_page_config(
        page_title="Mortgage Risk Stress Tester",
        page_icon="📊",
        layout="wide",
    )

    # Global styling
    st.markdown(
        """
        <style>
        .block-container {
            padding-top: 1.3rem;
            padding-bottom: 1rem;
            padding-left: 3rem;
            padding-right: 3rem;
        }
        .metric-card {
            padding: 1rem 1.2rem;
            border-radius: 0.8rem;
            border: 1px solid #e5e5e5;
            background: #fafafa;
        }
        .metric-label {
            font-size: 0.8rem;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.06em;
        }
        .metric-value {
            font-size: 1.5rem;
            font-weight: 700;
            margin-top: 0.1rem;
        }
        .metric-delta {
            font-size: 0.9rem;
            color: #16a34a;
            margin-top: 0.1rem;
        }
        .badge {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            border-radius: 999px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-left: 0.35rem;
        }
        .badge-realistic {
            background: rgba(56,189,248,0.12);
            color: #0369a1;
        }
        .badge-relative {
            background: rgba(74,222,128,0.12);
            color: #166534;
        }
        .scenario-pill {
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            padding: 0.35rem 0.75rem;
            border-radius: 999px;
            background: #f3f4f6;
            font-size: 0.8rem;
            color: #374151;
        }
        .scenario-dot {
            width: 0.5rem;
            height: 0.5rem;
            border-radius: 999px;
            background: #3b82f6;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Load artifacts
    try:
        art = load_artifacts()
    except Exception as e:
        st.error(
            "Could not load `artifacts/stress_app_artifacts.npz`.\n\n"
            "Make sure you ran the export cell in your notebook in this folder."
        )
        st.exception(e)
        st.stop()

    P_REL = art["p_baseline_rel"]
    P_REAL = art["p_baseline_real"]
    SU, SH, SR = art["su"], art["sh"], art["sr"]
    WU, WH, WR = art["wu"], art["wh"], art["wr"]

    base_mean_rel = float(P_REL.mean())
    base_mean_real = float(P_REAL.mean())

    # Sidebar
    st.sidebar.title("⚙️ Configuration")
    st.sidebar.markdown(
        "Choose PD version and macro scenario. "
        "The dashboard updates automatically."
    )

    pd_base_type = st.sidebar.radio(
        "Probability version",
        ["Realistic (anchored base rate)", "Relative (sample prevalence)"],
        index=0,
    )

    if pd_base_type.startswith("Realistic"):
        p0 = P_REAL
        base_mean = base_mean_real
        pd_badge_class = "badge-realistic"
        pd_badge_text = "REALISTIC"
    else:
        p0 = P_REL
        base_mean = base_mean_rel
        pd_badge_class = "badge-relative"
        pd_badge_text = "RELATIVE"

    scenario_name = st.sidebar.selectbox(
        "Scenario",
        list(PRESET_SCENARIOS.keys()),
        index=1,
    )

    if scenario_name == "Custom":
        st.sidebar.markdown("#### Custom macro shocks")

        unrate_delta = st.sidebar.slider(
            "Δ Unemployment rate (pp)",
            min_value=-2.0,
            max_value=10.0,
            value=2.0,
            step=0.5,
        )
        hpi_delta = st.sidebar.slider(
            "Δ House price index (%)",
            min_value=-40.0,
            max_value=10.0,
            value=-10.0,
            step=1.0,
        )
        rate_delta = st.sidebar.slider(
            "Δ Mortgage rate (pp)",
            min_value=-2.0,
            max_value=5.0,
            value=1.0,
            step=0.25,
        )

        delta = {
            "UNRATE": unrate_delta,
            "HPI_CHANGE": hpi_delta,
            "MORTGAGE30US": rate_delta,
        }
    else:
        delta = PRESET_SCENARIOS[scenario_name]

    st.sidebar.caption(
        "Shocks are interpreted as changes relative to the macro levels used "
        "when training the model."
    )

    # Header
    left, right = st.columns([3, 1])

    with left:
        st.markdown(
            """
            <h1 style="margin-bottom:0.1rem;">📊 Mortgage Risk Stress Tester</h1>
            <p style="color:#4b5563; font-size:0.95rem; margin-top:0;">
            Explore how portfolio default probabilities respond to macroeconomic stress.
            </p>
            """,
            unsafe_allow_html=True,
        )
        st.markdown(
            f"""
            <div class="scenario-pill">
              <div class="scenario-dot"></div>
              <span><strong>{scenario_name}</strong> scenario</span>
              <span style="color:#9ca3af;">|</span>
              <span>PD version:</span>
              <span class="badge {pd_badge_class}">{pd_badge_text}</span>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with right:
        st.write("")

    # ---------- Compute scenario ----------
    p_stressed, stressed_mean = apply_scenario(
        p0, delta, SU, SH, SR, WU, WH, WR
    )

    rel_change = (stressed_mean / base_mean - 1) * 100 if base_mean > 0 else None
    delta_pp = (stressed_mean - base_mean) * 100

    # Metric cards
    m1, m2, m3 = st.columns(3)

    with m1:
        st.markdown(
            f"""
            <div class="metric-card">
              <div class="metric-label">Baseline average PD</div>
              <div class="metric-value">{100 * base_mean:.2f} %</div>
              <div style="font-size:0.8rem; color:#6b7280;">
                Portfolio-level PD without macro shock.
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with m2:
        st.markdown(
            f"""
            <div class="metric-card">
              <div class="metric-label">{scenario_name} average PD</div>
              <div class="metric-value">{100 * stressed_mean:.2f} %</div>
              <div class="metric-delta">
                {delta_pp:+.2f} pp vs baseline
              </div>
              <div style="font-size:0.8rem; color:#6b7280;">
                After applying the selected macro shocks.
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    with m3:
        if rel_change is None:
            rel_text = "N/A"
            color = "#6b7280"
        else:
            rel_text = f"{rel_change:+.1f} %"
            color = "#16a34a" if rel_change >= 0 else "#b91c1c"

        st.markdown(
            f"""
            <div class="metric-card">
              <div class="metric-label">Relative change</div>
              <div class="metric-value" style="color:{color};">{rel_text}</div>
              <div style="font-size:0.8rem; color:#6b7280;">
                Percentage change of mean PD under stress vs baseline.
              </div>
            </div>
            """,
            unsafe_allow_html=True,
        )

    # Scenario details
    with st.expander("Scenario details (current shocks vs history)", expanded=False):
        scen_df = pd.DataFrame(
            {
                "Driver": ["Unemployment rate", "House price change", "Mortgage rate"],
                "Code": ["UNRATE", "HPI_CHANGE", "MORTGAGE30US"],
                "Shock": [
                    delta.get("UNRATE", 0.0),
                    delta.get("HPI_CHANGE", 0.0),
                    delta.get("MORTGAGE30US", 0.0),
                ],
                "Historical std dev": [SU, SH, SR],
            }
        )
        scen_df["Shock / std dev"] = scen_df["Shock"] / scen_df["Historical std dev"]
        st.table(scen_df.set_index("Code").round(3))

    st.markdown("---")

    # Tabs
    tab_overview, tab_dist, tab_step, tab_sens = st.tabs(
        ["Overview", "PD distributions", "Stepwise build-up", "Macro sensitivity"]
    )

    # Overview tab
    with tab_overview:
        st.subheader("Baseline vs stressed average PD")

        overview_df = pd.DataFrame(
            {
                "Scenario": ["Baseline", scenario_name],
                "Mean PD (%)": [100 * base_mean, 100 * stressed_mean],
            }
        )

        bar_chart = (
            alt.Chart(overview_df)
            .mark_bar(cornerRadiusTopLeft=6, cornerRadiusTopRight=6)
            .encode(
                x=alt.X("Scenario:N", axis=alt.Axis(title=None)),
                y=alt.Y("Mean PD (%):Q", axis=alt.Axis(title="Mean PD (%)")),
                color=alt.Color(
                    "Scenario:N",
                    scale=alt.Scale(
                        domain=["Baseline", scenario_name],
                        range=["#9ca3af", "#3b82f6"],
                    ),
                    legend=None,
                ),
                tooltip=["Scenario", alt.Tooltip("Mean PD (%):Q", format=".2f")],
            )
            .properties(height=260)
        )

        st.altair_chart(bar_chart, use_container_width=True)

        st.markdown(
            """
            <p style="font-size:0.9rem; color:#4b5563; margin-top:0.6rem;">
            The bar chart compares the portfolio average PD before and after the scenario. 
            Switch PD versions or scenarios in the sidebar to see how sensitive the portfolio is.
            </p>
            """,
            unsafe_allow_html=True,
        )

    # PD distributions tab
    with tab_dist:
        st.subheader("Distribution of loan-level PDs")

        df_dist = pd.DataFrame(
            {
                "PD": np.concatenate([p0, p_stressed]),
                "Scenario": (["Baseline"] * len(p0)) + ([scenario_name] * len(p_stressed)),
            }
        )
        df_dist["PD_pct"] = df_dist["PD"] * 100

        hist = (
            alt.Chart(df_dist)
            .transform_bin("PD_bin", field="PD_pct", bin=alt.Bin(maxbins=40))
            .mark_bar(opacity=0.55)
            .encode(
                x=alt.X("PD_bin:Q", title="Loan-level PD (%)"),
                y=alt.Y("count()", title="Number of loans"),
                color=alt.Color(
                    "Scenario:N",
                    scale=alt.Scale(range=["#9ca3af", "#3b82f6"]),
                ),
                tooltip=[
                    "Scenario:N",
                    alt.Tooltip("PD_bin:Q", title="PD bin", format=".1f"),
                    "count():Q",
                ],
            )
            .properties(height=280)
        )

        st.altair_chart(hist, use_container_width=True)

        st.markdown(
            """
            <p style="font-size:0.9rem; color:#4b5563; margin-top:0.6rem;">
            This view shows how the entire distribution of PDs shifts under stress, 
            not just the mean. A rightward shift signals broad-based deterioration.
            </p>
            """,
            unsafe_allow_html=True,
        )

    # ===== Stepwise build-up tab =====
    with tab_step:
        st.subheader("Stepwise macro shock build-up")

        step_df = scenario_step_df(
            p0, delta, SU, SH, SR, WU, WH, WR
        )

        step_chart = (
            alt.Chart(step_df)
            .mark_line(point=True)
            .encode(
                x=alt.X("Stage:N", sort=None, axis=alt.Axis(title=None)),
                y=alt.Y("Mean_PD_pct:Q", axis=alt.Axis(title="Mean PD (%)")),
                tooltip=[
                    "Stage:N",
                    alt.Tooltip("Mean_PD_pct:Q", title="Mean PD (%)", format=".2f"),
                    alt.Tooltip("Δ_from_baseline_pp:Q", title="Δ vs baseline (pp)", format=".2f"),
                ],
                color=alt.value("#3b82f6"),
            )
            .properties(height=280)
        )

        st.altair_chart(step_chart, use_container_width=True)

        st.markdown("**Detailed numbers**")
        st.dataframe(
            step_df[["Stage", "Mean_PD_pct", "Δ_from_baseline_pp"]]
            .rename(
                columns={
                    "Mean_PD_pct": "Mean PD (%)",
                    "Δ_from_baseline_pp": "Δ vs baseline (pp)",
                }
            ),
            use_container_width=True,
        )

        st.markdown(
            """
            <p style="font-size:0.9rem; color:#4b5563; margin-top:0.6rem;">
            The line shows how much each driver (unemployment, HPI, mortgage rates) 
            contributes as you layer the shocks in. This mirrors the stepwise chart 
            from your notebook but in a cleaner, interactive layout.
            </p>
            """,
            unsafe_allow_html=True,
        )

    # Macro sensitivity tab
    with tab_sens:
        st.subheader("Macro sensitivity curves")

        st.markdown(
            """
            <p style="font-size:0.9rem; color:#4b5563;">
            These curves show how the portfolio mean PD would move if you varied one
            macro variable at a time, holding the others fixed. The vertical dashed
            line marks the current scenario shock for that driver.
            </p>
            """,
            unsafe_allow_html=True,
        )

        driver_options = {
            "UNRATE": {
                "label": "Unemployment rate (Δ pp)",
                "grid": np.linspace(-2, 6, 33),
                "x_title": "Δ UNRATE (percentage points)",
            },
            "HPI_CHANGE": {
                "label": "House price change (Δ %)",
                "grid": np.linspace(-30, 10, 41),
                "x_title": "Δ HPI (%)",
            },
            "MORTGAGE30US": {
                "label": "Mortgage rate (Δ pp)",
                "grid": np.linspace(-2, 4, 25),
                "x_title": "Δ mortgage rate (percentage points)",
            },
        }

        selected_drivers = st.multiselect(
            "Select drivers to display",
            options=list(driver_options.keys()),
            default=["UNRATE", "HPI_CHANGE"],
            format_func=lambda k: driver_options[k]["label"],
        )

        if not selected_drivers:
            st.info("Select at least one driver above to see sensitivity curves.")
        else:
            for drv in selected_drivers:
                cfg = driver_options[drv]
                grid = cfg["grid"]

                df_curve = sweep_driver_curve(
                    p0, drv, grid, SU, SH, SR, WU, WH, WR
                )
                df_curve["mean_PD_pct"] = df_curve["mean_PD"] * 100

                # Current scenario shock for this driver
                current_shock = float(delta.get(drv, 0.0))

                curve = (
                    alt.Chart(df_curve)
                    .mark_line(point=True)
                    .encode(
                        x=alt.X("shock:Q", title=cfg["x_title"]),
                        y=alt.Y("mean_PD_pct:Q", title="Mean PD (%)"),
                        tooltip=[
                            alt.Tooltip("shock:Q", title="Shock", format=".2f"),
                            alt.Tooltip("mean_PD_pct:Q", title="Mean PD (%)", format=".2f"),
                        ],
                        color=alt.value("#3b82f6"),
                    )
                    .properties(height=260)
                )

                marker_df = pd.DataFrame({"shock": [current_shock]})
                marker = (
                    alt.Chart(marker_df)
                    .mark_rule(strokeDash=[6, 4], color="#ef4444")
                    .encode(x="shock:Q")
                )

                st.altair_chart(curve + marker, use_container_width=True)

                st.caption(
                    f"{cfg['label']}: current scenario shock = {current_shock:+.2f} "
                    f" ({current_shock / (SU if drv=='UNRATE' else SH if drv=='HPI_CHANGE' else SR):+.2f} σ)"
                )

    st.markdown(
        """
        <p style="font-size:0.75rem; color:#9ca3af; margin-top:1.4rem;">
        Built on your calibrated credit risk model and macro sensitivity parameters 
        exported from the original analysis notebook.
        </p>
        """,
        unsafe_allow_html=True,
    )


if __name__ == "__main__":
    main()
